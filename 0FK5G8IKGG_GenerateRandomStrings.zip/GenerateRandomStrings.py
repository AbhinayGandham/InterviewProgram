import string 
import random

def generateRandomStrings(s):
    n = len(s)
    chars = string.ascii_letters + string.digits + string.punctuation
   
    i = 0
    rand_string = ''.join(random.choices(chars,k=n-i))
    new_string = ''
    while(True):
        rand_string = new_string + ''.join(random.choices(chars,k=n-i))
        if i == n:
            break;
        if rand_string[i] == s[i]:
            i += 1 
            new_string = rand_string[:i]
            
            print(rand_string)
        if ((rand_string) == s):
            break;
        
        print(rand_string)
generateRandomStrings("ab27")